# ChickenGun Neon Menu (demo)

Android demo of a draggable floating neon panel. The toggles are visual only and do not interact with Chicken Gun or alter gameplay.

## Build
Run `gradle assembleDebug` with JDK 17 and Android SDK installed, or use the included GitHub Actions workflow. The APK is published as a workflow artifact.
