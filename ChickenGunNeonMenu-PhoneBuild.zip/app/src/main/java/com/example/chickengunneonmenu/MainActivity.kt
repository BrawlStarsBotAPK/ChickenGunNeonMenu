package com.example.chickengunneonmenu

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 40, 28, 24)
            setBackgroundColor(0xFF101522.toInt())
        }
        val title = TextView(this).apply {
            text = "BLUE NEON MENU"
            textSize = 25f
            setTextColor(0xFF39D9FF.toInt())
        }
        val info = TextView(this).apply {
            text = "\nДемо плавающего меню. Оно отображается поверх приложений, но не изменяет Chicken Gun и не управляет игровыми функциями.\n"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val grant = Button(this).apply {
            text = "Разрешить отображение поверх окон"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else startOverlay()
            }
        }
        val start = Button(this).apply {
            text = "Запустить плавающее меню"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) startOverlay()
                else Toast.makeText(this@MainActivity, "Сначала разреши отображение поверх окон", Toast.LENGTH_LONG).show()
            }
        }
        layout.addView(title); layout.addView(info); layout.addView(grant); layout.addView(start)
        setContentView(layout)
    }
    private fun startOverlay() {
        startForegroundService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "Плавающее меню запущено", Toast.LENGTH_SHORT).show()
        finish()
    }
}
