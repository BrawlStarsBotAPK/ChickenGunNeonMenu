package com.example.chickengunneonmenu

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private val cyan = Color.rgb(45, 220, 255)
    private val flags = mutableMapOf("ESP (демо)" to false, "Aimbot (демо)" to false,
        "No Recoil (демо)" to false, "Speed (демо)" to false, "Jump Boost (демо)" to false)

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val channel = "neon_menu"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channel, "Neon menu", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channel).setContentTitle("Neon menu работает")
                .setContentText("Нажми на плавающий значок, чтобы открыть меню")
                .setSmallIcon(android.R.drawable.ic_dialog_info).build()
        else Notification.Builder(this).setContentTitle("Neon menu работает")
            .setSmallIcon(android.R.drawable.ic_dialog_info).build()
        startForeground(7, notification)
        showBubble()
    }

    private fun params(): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30; y = 180
        }
    }
    private fun neonBg() = GradientDrawable().apply {
        setColor(Color.rgb(13, 22, 39)); cornerRadius = 22f
        setStroke(2, cyan)
    }
    private fun label(text: String, size: Float = 16f) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(Color.WHITE)
        setPadding(18, 13, 18, 13); typeface = Typeface.DEFAULT_BOLD
    }
    private fun showBubble() {
        val b = label("✦", 24f).apply {
            gravity = Gravity.CENTER; background = neonBg()
            setOnClickListener { if (panel == null) showPanel() else closePanel() }
        }
        bubble = b
        wm.addView(b, params())
        makeDraggable(b)
    }
    private fun showPanel() {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = neonBg()
            setPadding(8, 8, 8, 8)
        }
        val head = label("BLUE NEON  •  DEMO", 18f).apply { setTextColor(cyan) }
        p.addView(head)
        flags.forEach { (name, _) ->
            val row = TextView(this).apply {
                text = "$name     OFF"; textSize = 15f; setTextColor(Color.WHITE)
                setPadding(18, 12, 18, 12)
                setOnClickListener {
                    flags[name] = !(flags[name] ?: false)
                    text = "$name     " + if (flags[name] == true) "ON" else "OFF"
                    setTextColor(if (flags[name] == true) cyan else Color.WHITE)
                }
            }
            p.addView(row)
        }
        p.addView(label("Это только визуальные переключатели", 12f).apply { setTextColor(0xFFB8C7D9.toInt()) })
        val close = label("ЗАКРЫТЬ").apply {
            gravity = Gravity.CENTER; setTextColor(cyan); setOnClickListener { closePanel() }
        }
        p.addView(close)
        panel = p
        val lp = params().apply { x = 95; y = 190 }
        wm.addView(p, lp)
        makeDraggable(p)
    }
    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }
    private fun makeDraggable(view: View) {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        view.setOnTouchListener { _, e ->
            val lp = view.layoutParams as WindowManager.LayoutParams
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; false }
                MotionEvent.ACTION_MOVE -> { lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt(); wm.updateViewLayout(view, lp); true }
                else -> false
            }
        }
    }
    override fun onDestroy() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
